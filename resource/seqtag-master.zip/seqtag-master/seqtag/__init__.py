__version__ = '1.0.8'
__author__ = 'Originally authored by https://github.com/guillaumegenthial. Packaged and imporvements, bug corrections by Bedapudi Praneeth (@bedapudi6788)'
